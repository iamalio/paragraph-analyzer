function countWords() {

    var input = document.getElementById('textarea').value;
    var calculate = document.getElementById('analyzer');
    
    var spaces = 0;
    var words = 0;
    var sentences =0;
    var averageWords = 0;
    
    for(var i =0; i< input.length; i++)
        {
            if(input[i] == " ")
                {
                spaces++;
                }
            if(input[i]=="." || input[i]=="?" || input[i]=="!")
                {
                sentences++;
                }
        }
    
    words = spaces + 1;
    averageWords = words / sentences;
        
    document.getElementById("spaceTotal").innerHTML = spaces;
    document.getElementById("wordsTotal").innerHTML = words;
    document.getElementById("sentenceTotal").innerHTML = sentences;
    document.getElementById("averageWordsper").innerHTML = averageWords;
    
    
}